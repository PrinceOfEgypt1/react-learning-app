// backup.js

const fs = require('fs');
const path = require('path');
const archiver = require('archiver');

// 1. Defina a raiz do projeto e o diretório de Backup
const projectRoot = path.resolve(__dirname);
const backupDir = path.join(projectRoot, 'Backup');

// 2. Cria a pasta de backup se não existir
if (!fs.existsSync(backupDir)) {
  fs.mkdirSync(backupDir, { recursive: true });
}

// 3. Gera timestamp no formato ddmmaaaa_hhmmss
const now = new Date();
const pad = n => String(n).padStart(2, '0');
const dd = pad(now.getDate());
const mm = pad(now.getMonth() + 1);
const yyyy = now.getFullYear();
const hh = pad(now.getHours());
const min = pad(now.getMinutes());
const ss = pad(now.getSeconds());
const timestamp = `${dd}${mm}${yyyy}_${hh}${min}${ss}`;

// 4. Define nome e caminho do arquivo de backup
const backupFileName = `Backup_Completo_Projeto_${timestamp}.zip`;
const outputPath = path.join(backupDir, backupFileName);

// 5. Prepara stream de escrita e instância do archiver
const output = fs.createWriteStream(outputPath);
const archive = archiver('zip', { zlib: { level: 9 } });

output.on('close', () => {
  console.log(`✔ Backup concluído: ${backupFileName} (${archive.pointer()} bytes)`);
});
archive.on('warning', err => {
  if (err.code !== 'ENOENT') throw err;
});
archive.on('error', err => { throw err; });

// 6. Inicia o pipe para o arquivo zip
archive.pipe(output);

// 7. Define padrões de exclusão
const ignorePatterns = [
  'Arquivos de Códigos/**',   // não copiar essa pasta
  'coletar-codigo.js',        // não copiar este arquivo
  'node_modules/**',          // não copiar dependências
  'package-lock.json',        // não copiar o lock file
  'Backup/**'                 // não incluir backups anteriores
];

// 8. Adiciona todos os arquivos (inclusive ocultos), exceto os ignorados
archive.glob('**/*', {
  cwd: projectRoot,
  dot: true,       // inclui .gitignore, .eslintrc.js, etc.
  ignore: ignorePatterns
});

// 9. Finaliza o processo de compressão
archive.finalize();

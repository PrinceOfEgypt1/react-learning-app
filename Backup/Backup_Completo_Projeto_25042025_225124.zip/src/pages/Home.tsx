// src/pages/Home.tsx
import React from 'react';
import { HeroCard } from '../components/HeroCard';
import { Card } from '../components/Card';

function Home() {
  return (
    <div className="container">
      <h1>Aplicação de Aprendizagem</h1>
      <p className="subtitle">Lógica de Programação, Algoritmos, Java e Python</p>

      <HeroCard />

      <div className="grid">
        <Card title="Python para Iniciantes" disabled />
        <Card title="Java Fundamental" disabled />
        <Card title="Fundamentos de Desenvolvimento Web" disabled />
        <Card title="Python para Web (Back-end)" disabled />
        <Card title="Java para Web (Back-end)" disabled />
        <Card title="Desenvolvimento Full-Stack" disabled />
      </div>
    </div>
  );
}

export default Home;
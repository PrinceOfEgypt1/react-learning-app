// src/pages/TopicPage.tsx
import React from 'react';
import { useParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { fundamentos } from '../data/fundamentos';

function TopicPage() {
  const { topicId } = useParams();
  const topic = fundamentos.find(t => t.id === topicId);

  if (!topic) {
    return (
      <motion.div 
        className="container"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.4 }}
      >
        <Link to="/fundamentos" className="button-back">← Voltar a Fundamentos</Link>
        <div className="error-message">
          <h2>Tópico não encontrado</h2>
          <p>O tópico solicitado não está disponível ou foi removido.</p>
        </div>
      </motion.div>
    );
  }

  // Animações para seções diferentes
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: { 
      opacity: 1,
      transition: { 
        when: "beforeChildren",
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <motion.div 
      className="container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <Link to="/fundamentos" className="button-back">← Voltar a Fundamentos</Link>
      
      <motion.h1 variants={itemVariants}>{topic.title}</motion.h1>
      <motion.p 
        className="topic-content" 
        variants={itemVariants}
      >
        {topic.content}
      </motion.p>

      <motion.div className="topic-sections" variants={itemVariants}>
        <details>
          <summary>Exemplos</summary>
          <div className="examples-container">
            {topic.examples.map((ex, idx) => (
              <motion.div 
                key={idx}
                className="example-item"
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: idx * 0.1 }}
              >
                <pre data-language={
                  ex.code.startsWith('// Java') ? 'Java' : 
                  ex.code.startsWith('# Python') ? 'Python' : 
                  ex.code.includes('algoritmo') ? 'Portugol' : 'Code'
                }>
                  {ex.code}
                </pre>
                <p className="example-description">{ex.description}</p>
              </motion.div>
            ))}
          </div>
        </details>

        <details>
          <summary>Exercícios</summary>
          <ul className="exercises-list">
            {topic.exercises.map((ex, idx) => (
              <li key={idx} className="exercise-item">
                {ex}
              </li>
            ))}
          </ul>
        </details>

        <details>
          <summary>Recursos</summary>
          <ul className="resources-list">
            {topic.resources.map((r, idx) => (
              <li key={idx} className="resource-item">
                <a 
                  href={r.url} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="resource-link"
                >
                  {r.title}
                </a>
              </li>
            ))}
          </ul>
        </details>
      </motion.div>
    </motion.div>
  );
}

export default TopicPage;
// src/pages/FundamentosOverview.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { Card } from '../components/Card';
import { fundamentos } from '../data/fundamentos';

function FundamentosOverview() {
  return (
    <div className="container">
      <Link to="/" className="button-back">
        ← Voltar à Página Inicial
      </Link>
      <h1>Fundamentos da Programação</h1>
      <p className="subtitle">Selecione um tópico:</p>
      <div className="grid">
        {fundamentos.map(topic => (
          <Card key={topic.id} title={topic.title} to={`/fundamentos/${topic.id}`} />
        ))}
      </div>
    </div>
  );
}

export default FundamentosOverview;
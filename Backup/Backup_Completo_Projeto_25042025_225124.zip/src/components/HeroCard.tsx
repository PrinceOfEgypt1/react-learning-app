import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from './Button';

export function HeroCard() {
  return (
    <motion.div
      className="hero-card"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      whileHover={{ scale: 1.03 }}
    >
      <h2>Fundamentos da Programação</h2>
      <p>Lógica, algoritmos, estruturas de decisão e geração.</p>
      <Link to="/fundamentos">
        <Button variant="secondary">Explorar Fundamentos</Button>
      </Link>
    </motion.div>
  );
}
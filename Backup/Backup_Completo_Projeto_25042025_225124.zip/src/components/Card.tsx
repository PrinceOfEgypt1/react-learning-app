// src/components/Card.tsx
import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Button } from './Button';

interface CardProps {
  title: string;
  subtitle?: string;
  to?: string;
  disabled?: boolean;
  index?: number; // Adicionar propriedade de índice
}

export function Card({ title, subtitle, to, disabled, index = 0 }: CardProps) {
  // Aplicar índice para animação escalonada
  const style = { '--card-index': index } as React.CSSProperties;
  
  return (
    <motion.div
      className="card"
      style={style}
      whileHover={{ scale: to && !disabled ? 1.03 : 1 }}
    >
      <h3>{title}</h3>
      {subtitle && <p>{subtitle}</p>}
      {to ? (
        <Link to={to}>
          <Button disabled={disabled}>Ver Detalhes</Button>
        </Link>
      ) : (
        <Button disabled>Em Breve</Button>
      )}
    </motion.div>
  );
}
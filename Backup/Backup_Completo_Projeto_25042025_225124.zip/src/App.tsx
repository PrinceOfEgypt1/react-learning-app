// src/App.tsx com lazy loading
import React, { Suspense, lazy } from 'react';
import { Routes, Route, Link, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import './App.css';

// Lazy loading dos componentes
const Home = lazy(() => import('./pages/Home'));
const FundamentosOverview = lazy(() => import('./pages/FundamentosOverview'));
const TopicPage = lazy(() => import('./pages/TopicPage'));

export default function App() {
  const location = useLocation();
  
  return (
    <div>
      <nav className="container" aria-label="Menu Principal">
        <Link to="/">Home</Link> | <Link to="/fundamentos">Fundamentos</Link>
      </nav>

      <main className="container">
        <Suspense fallback={<div>Carregando...</div>}>
          <AnimatePresence mode="wait">
            <Routes location={location} key={location.pathname}>
              <Route path="/" element={<Home />} />
              <Route path="/fundamentos" element={<FundamentosOverview />} />
              <Route path="/fundamentos/:topicId" element={
                <motion.div
                  initial={{ opacity: 0, x: 50 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -50 }}
                  transition={{ duration: 0.4 }}
                >
                  <TopicPage />
                </motion.div>
              } />
            </Routes>
          </AnimatePresence>
        </Suspense>
      </main>
    </div>
  );
}
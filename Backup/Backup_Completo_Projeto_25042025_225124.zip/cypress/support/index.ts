// cypress/support/index.ts
// Arquivo principal de suporte do Cypress
// Importa comandos customizados, se houver
import './commands';